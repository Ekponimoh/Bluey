"use strict";

const slider = document.querySelector(".section-slider");
const slides = document.querySelectorAll(".slider-grid");
console.log(slider, slides);

let curSlide = 0;
const maxSlide = slides.length - 1;

const goToSlide = (slide) => {
    slides.forEach((sld, i) => {
        sld.style.transform = `translateX(${[i - slide] * 100}%)`
    })
}
goToSlide(0);


const createDots = () => {
    const dots = `
        <div class="dots">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
        </div>
    `

    slider.insertAdjacentHTML("beforeend", dots);
}
createDots();

const activateDot = (slide) => {
    const allDots = document.querySelectorAll(".dot");
    allDots.forEach((dot, i) => {
        dot.classList.remove("dot--fill");
        if (i === slide) {
            dot.classList.add("dot--fill");
            goToSlide(slide);
        }
    })
}

activateDot(curSlide);


const nextSlide = () => {
    if (curSlide === maxSlide) {
        curSlide = 0;
        goToSlide(curSlide);
        activateDot(curSlide)
    } else {
        curSlide++
        goToSlide(curSlide);
        activateDot(curSlide)
    }
}

setInterval(() => {
    nextSlide();
}, 5000);